"""M4 detection, M5 learned interior points and SAM boundary refinement."""
from pathlib import Path
import os
os.environ.setdefault('YOLO_CONFIG_DIR',str(Path(__file__).parent/'runtime_config'))
import argparse,json,hashlib,urllib.request,shutil
import numpy as np
import cv2
import torch
from PIL import Image,ImageDraw
from ultralytics import YOLO,SAM

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def render(polygons,w,h):
    canvas=Image.new('1',(w,h));draw=ImageDraw.Draw(canvas)
    for poly in polygons:
        if len(poly)>=3:draw.polygon([(float(x*w),float(y*h)) for x,y in poly],fill=1)
    return np.asarray(canvas,dtype=bool)

def box_iou(a,b):
 a=np.asarray(a).reshape(-1,4);b=np.asarray(b).reshape(-1,4)
 if not len(a) or not len(b):return np.zeros((len(a),len(b)))
 lo=np.maximum(a[:,None,:2],b[None,:,:2]);hi=np.minimum(a[:,None,2:],b[None,:,2:])
 inter=np.maximum(hi-lo,0).prod(-1);aa=np.maximum(a[:,2:]-a[:,:2],0).prod(-1);bb=np.maximum(b[:,2:]-b[:,:2],0).prod(-1)
 return inter/np.maximum(aa[:,None]+bb[None,:]-inter,1e-9)
def predict_image(detector,model,sam,path,policy,device):
    det=detector.predict(str(path),imgsz=policy['detector_input'],conf=policy['prompt_floor'],iou=policy['detector_nms'],verbose=False,device=device)[0]
    boxes=det.boxes.xyxy.cpu().numpy()[:policy['max_prompts']]
    confs=det.boxes.conf.cpu().numpy()[:policy['max_prompts']]
    h,w=det.orig_shape
    objects=[]
    if len(boxes):
        learned=model.predict(str(path),imgsz=policy['segmenter_input'],conf=policy['segmenter_conf'],iou=policy['segmenter_nms'],retina_masks=True,verbose=False,device=device)[0]
        overlap=box_iou(boxes,learned.boxes.xyxy.cpu().numpy())
        points=[];methods=[]
        for j,box in enumerate(boxes):
            chosen=int(overlap[j].argmax()) if overlap.shape[1] else -1
            point=None
            if chosen>=0 and overlap[j,chosen]>=policy['matching_iou'] and learned.masks is not None and chosen<len(learned.masks):
                mask=learned.masks.data[chosen].cpu().numpy().astype('uint8').copy()
                x1,y1,x2,y2=box
                left=max(0,int(x1));top=max(0,int(y1));right=min(mask.shape[1],int(np.ceil(x2)));bottom=min(mask.shape[0],int(np.ceil(y2)))
                clipped=np.zeros_like(mask);clipped[top:bottom,left:right]=mask[top:bottom,left:right]
                distance=cv2.distanceTransform(clipped,cv2.DIST_L2,3)
                if distance.max()>0:
                    y,x=np.unravel_index(int(distance.argmax()),distance.shape);point=[float(x),float(y)]
            methods.append('learned_mask' if point is not None else 'box_center')
            points.append([point if point is not None else [float((box[0]+box[2])/2),float((box[1]+box[3])/2)]])
        refined=sam.predict(str(path),bboxes=boxes.tolist(),points=points,labels=[[1] for _ in points],conf=0.,imgsz=policy['sam_input'],verbose=False,device=device)[0]
        shapes=refined.masks.xyn if refined.masks is not None else []
        indices=refined.boxes.cls.cpu().numpy().astype(int).tolist()
        assert len(indices)==len(shapes)
        for shape,quality,j in zip(shapes,refined.boxes.conf.cpu().numpy().tolist(),indices):
            if float(confs[j])<policy['conf'] or quality<policy['sam_quality']:continue
            objects.append(dict(box_xyxy_normalized=(boxes[j]/np.array([w,h,w,h])).tolist(),confidence=float(confs[j]),sam_quality=quality,point_method=methods[j],polygon_normalized=shape.tolist()))
    return dict(image=str(path),mask_count=len(objects),detector_prompt_count=len(boxes),detector_prompt_count_capped=True,objects=objects,foreground_area_fraction=float(render([o['polygon_normalized'] for o in objects],w,h).mean()))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--images',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--policy',type=Path,default=Path(__file__).with_name('refinement_policy.json'));parser.add_argument('--device',default=None)
    args=parser.parse_args();policy=json.loads(args.policy.read_text());folder=args.policy.parent
    weights=folder/policy['model_file'];assert digest(weights)==policy['model_sha256']
    mobile=folder/policy['sam_file']
    if not mobile.exists():
        for candidate in (Path.cwd()/policy['sam_file'],Path('/content')/policy['sam_file']):
            if candidate.is_file() and digest(candidate)==policy['sam_sha256']:
                shutil.copyfile(candidate,mobile)
                break
    if not mobile.exists():
        temporary=mobile.with_suffix('.download')
        with urllib.request.urlopen(policy['sam_url'],timeout=120) as source,temporary.open('wb') as output:
            while chunk:=source.read(1024*1024):output.write(chunk)
        assert digest(temporary)==policy['sam_sha256'],'Downloaded SAM checksum differs'
        temporary.replace(mobile)
    assert digest(mobile)==policy['sam_sha256']
    detector_weights=folder/policy['detector_file'];assert digest(detector_weights)==policy['detector_sha256']
    detector=YOLO(str(detector_weights));model=YOLO(str(weights));sam=SAM(str(mobile))
    if policy.get('multimask',False):
        original_decoder=sam.model.mask_decoder.forward
        def multimask_decoder(*args,**kwargs):
            kwargs['multimask_output']=True
            return original_decoder(*args,**kwargs)
        sam.model.mask_decoder.forward=multimask_decoder
    device=args.device or ('0' if torch.cuda.is_available() else 'cpu')
    paths=sorted(p for p in args.images.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png','.webp')) if args.images.is_dir() else [args.images]
    results=[predict_image(detector,model,sam,path,policy,device) for path in paths]
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(dict(policy_sha256=digest(args.policy),results=results),indent=2));print(args.output)
if __name__=='__main__':main()
