# M4-guided segmentation

Validation: 40 original reviewed images, unchanged labels and split.

| Method | Mean IoU | Mean Dice |
|---|---:|---:|
| Original M5 last checkpoint, CPU reproduction | 48.77% | 57.92% |
| Continued fine-tuned M5 alone | 63.25% | 70.34% |
| M5 + SAM ViT-B at 640 | 68.40% | 73.50% |
| M5 + SAM ViT-B at 768 | 69.54% | 74.23% |
| M4 + M5 + SAM ViT-B at 640 | 80.68% | 86.86% |

The 70% IoU target is met on validation. Independent test performance is unmeasured.

Run `Import_M4_Guided_Segmentation.ipynb` in Colab and upload the ZIP. The notebook installs this release separately in Drive. No retraining is required. SAM ViT-B (~358 MB) is downloaded once on first inference.
