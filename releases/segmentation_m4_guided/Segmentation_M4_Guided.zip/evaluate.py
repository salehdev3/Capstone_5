from pathlib import Path
import os
BASE=Path(__file__).parent
(BASE/'analysis').mkdir(exist_ok=True)
os.environ['YOLO_CONFIG_DIR']=str(BASE/'runtime_config')
os.environ['MPLCONFIGDIR']=str(BASE/'mpl_config')
os.environ['OMP_NUM_THREADS']='4';os.environ['MKL_NUM_THREADS']='4'
import json,time,hashlib
import numpy as np
import pandas as pd
import torch
from PIL import Image,ImageDraw
from ultralytics import YOLO
ROOT=BASE/'transfer'
ROWS=json.loads((ROOT/'metadata/manifest_trainval.json').read_text())
VAL=[r for r in ROWS if r['split']=='val_select']
torch.set_num_threads(4)
try:torch.set_num_interop_threads(1)
except RuntimeError:pass

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def raster(polygons,w,h):
 canvas=Image.new('1',(w,h));draw=ImageDraw.Draw(canvas)
 for poly in polygons:
  if len(poly)>=3:draw.polygon([(float(x*w),float(y*h)) for x,y in poly],fill=1)
 return np.asarray(canvas,dtype=bool)
def ground_truth(row):
 text=(ROOT/'dataset/labels'/row['split']/(row['id']+'.txt')).read_text()
 polygons=[np.asarray([float(v) for v in line.split()[1:]]).reshape(-1,2) for line in text.splitlines() if line.strip()]
 return raster(polygons,row['width'],row['height'])
def evaluate(weight,imgsz=640,thresholds=(.01,.05,.1,.15,.2,.25,.3,.4,.5),tag=None):
 weight=Path(weight);identity=digest(weight);cache=BASE/'prediction_cache'/f'{identity}_{imgsz}_floor{min(thresholds)}.json'
 if cache.exists():predictions=json.loads(cache.read_text())
 else:
  model=YOLO(str(weight));predictions={}
  start=time.time()
  for i,r in enumerate(VAL):
   pred=model.predict(str(ROOT/'dataset/images/val_select'/(r['id']+'.jpg')),conf=min(thresholds),
      imgsz=imgsz,iou=.7,retina_masks=True,verbose=False,device='cpu')[0]
   polygons=pred.masks.xyn if pred.masks is not None else []
   predictions[r['id']]=dict(confidences=pred.boxes.conf.cpu().numpy().tolist(),polygons=[p.tolist() for p in polygons])
   if (i+1)%10==0:print('Inference',tag or weight.name,imgsz,i+1,'/40',round(time.time()-start,1),'s',flush=True)
  cache.parent.mkdir(exist_ok=True);cache.write_text(json.dumps(predictions))
 scores={conf:[] for conf in thresholds}
 for r in VAL:
  gt=ground_truth(r);p=predictions[r['id']]
  for conf in thresholds:
   chosen=[poly for score,poly in zip(p['confidences'],p['polygons']) if score>=conf]
   estimate=raster(chosen,r['width'],r['height']);inter=int((gt&estimate).sum());union=int((gt|estimate).sum())
   scores[conf].append(dict(id=r['id'],iou=inter/max(union,1),dice=2*inter/max(int(gt.sum()+estimate.sum()),1),
      area_mae_fraction=abs(float(gt.mean())-float(estimate.mean())),predicted_instances=len(chosen)))
 summary=[]
 for conf,values in scores.items():
  summary.append(dict(model=tag or weight.name,weights=str(weight),weights_sha256=identity,imgsz=imgsz,conf=conf,n=40,
     mean_iou=float(np.mean([r['iou'] for r in values])),mean_dice=float(np.mean([r['dice'] for r in values])),
     area_mae_fraction=float(np.mean([r['area_mae_fraction'] for r in values]))))
 return summary,scores
if __name__=='__main__':
 report=[]
 for size in (640,960,1280):
  table,_=evaluate(ROOT/'models/last.pt',imgsz=size,tag='original_last')
  report.extend(table);pd.DataFrame(report).to_csv(BASE/'analysis/inference_resolution_comparison.csv',index=False)
  print(pd.DataFrame(table).sort_values('mean_iou',ascending=False).head(2).to_string(index=False),flush=True)
