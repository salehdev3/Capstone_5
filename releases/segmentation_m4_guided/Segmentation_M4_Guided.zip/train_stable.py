from evaluate import *
import csv,platform
DERIVED=BASE/'derived_clean_training'
# Remove only six training polygons visually identified as background candidates
# outside the existing human animal boxes. Original files and validation are unchanged.
removals={
 '59ac6d21-23d2-11e8-a6a3-ec086b02610b':{1,2},
 '59f12913-23d2-11e8-a6a3-ec086b02610b':{1,2},
 '58b9d5b1-23d2-11e8-a6a3-ec086b02610b':{1},
 '59edef90-23d2-11e8-a6a3-ec086b02610b':{1}}
manifest=[]
for r in ROWS:
 for kind in ('images','labels'):(DERIVED/kind/r['split']).mkdir(parents=True,exist_ok=True)
 image=ROOT/'dataset/images'/r['split']/(r['id']+'.jpg')
 target=DERIVED/'images'/r['split']/image.name
 if not target.exists():target.symlink_to(image)
 label=ROOT/'dataset/labels'/r['split']/(r['id']+'.txt')
 lines=label.read_text().splitlines()
 remove=removals.get(r['id'],set()) if r['split']=='train' else set()
 filtered=[line for i,line in enumerate(lines) if i not in remove]
 assert filtered
 dest=DERIVED/'labels'/r['split']/label.name;dest.write_text('\n'.join(filtered)+'\n')
 manifest.append(dict(id=r['id'],split=r['split'],source_label_sha256=digest(label),derived_label_sha256=digest(dest),removed_indices=sorted(remove)))
(BASE/'analysis/derived_training_manifest.json').write_text(json.dumps(manifest,indent=2))
(DERIVED/'data.yaml').write_text(json.dumps(dict(path=str(DERIVED),train='images/train',val='images/val_select',names={0:'animal'}),indent=2))
RUN='stable_continued_clean'
from ultralytics.engine import trainer as trainer_module
trainer_module.autocast=lambda enabled: torch.autocast(device_type='cpu',dtype=torch.bfloat16,enabled=True)
plan=dict(source_sha256=digest(ROOT/'models/last.pt'),epochs=12,imgsz=640,batch=4,nbs=8,lr0=.0002,lrf=.1,
 optimizer='AdamW',cos_lr=True,warmup_epochs=0,warmup_bias_lr=0.0,patience=0,mosaic=0.,close_mosaic=0,scale=.15,translate=.05,
 hsv_h=.01,hsv_s=.15,hsv_v=.15,fliplr=.5,mask_ratio=4,overlap_mask=True,seed=42,workers=0,save_period=5,
 device='cpu',amp=False,plots=True)
(BASE/'analysis/training_plan_stable.json').write_text(json.dumps(dict(**plan,reference='validation labels frozen; six training-only background polygons removed',torch_version=torch.__version__,precision='CPU bfloat16 autocast; float32 optimizer',batch_norm='running statistics frozen',warmup_fix='disable fresh warmup on previously fine-tuned checkpoint',platform=platform.platform()),indent=2))
model=YOLO(str(ROOT/'models/last.pt'))
def freeze_batch_norm(trainer):
 for layer in trainer.model.modules():
  if isinstance(layer,torch.nn.modules.batchnorm._BatchNorm):layer.eval()
model.add_callback('on_train_epoch_start',freeze_batch_norm)
model.train(data=str(DERIVED/'data.yaml'),project=str(BASE/'experiments'),name=RUN,exist_ok=False,**{k:v for k,v in plan.items() if k!='source_sha256'})
print('TRAINING_COMPLETE',flush=True)
