from evaluate import *
from ultralytics import SAM
import cv2
SEG_WEIGHTS=Path('/workspace/exports/Segmentation_Assistant_Improvement/selected.pt')
DET_WEIGHTS=ROOT/'models/detector_best.pt'
detector=YOLO(str(DET_WEIGHTS));segmenter=YOLO(str(SEG_WEIGHTS));sam=SAM(str(BASE/'sam_b.pt'))
assert detector.task=='detect' and detector.names=={0:'animal'},(detector.task,detector.names)
identity=dict(detector_sha256=digest(DET_WEIGHTS),segmenter_sha256=digest(SEG_WEIGHTS),sam_sha256=digest(BASE/'sam_b.pt'),
 detector_input=640,segmenter_input=640,sam_input=640,prompt_floor=.045,detector_nms=.3,segmenter_conf=.05,segmenter_nms=.7,
 matching_iou=.3,max_prompts=10,point_method='interior distance of matched learned mask clipped to detected box; box-center fallback')
(BASE/'analysis/m4_guided_experiment.json').write_text(json.dumps(identity,indent=2))
cache_dir=BASE/('m4_guided_cache_'+identity['detector_sha256'][:8]+'_'+identity['segmenter_sha256'][:8]);cache_dir.mkdir(exist_ok=True)
def box_iou(a,b):
 a=np.asarray(a).reshape(-1,4);b=np.asarray(b).reshape(-1,4)
 if not len(a) or not len(b):return np.zeros((len(a),len(b)))
 lo=np.maximum(a[:,None,:2],b[None,:,:2]);hi=np.minimum(a[:,None,2:],b[None,:,2:])
 inter=np.maximum(hi-lo,0).prod(-1);aa=np.maximum(a[:,2:]-a[:,:2],0).prod(-1);bb=np.maximum(b[:,2:]-b[:,:2],0).prod(-1)
 return inter/np.maximum(aa[:,None]+bb[None,:]-inter,1e-9)
report=[]
for i,r in enumerate(VAL):
 cache=cache_dir/(r['id']+'.json')
 if cache.exists():p=json.loads(cache.read_text())
 else:
  path=str(ROOT/'dataset/images/val_select'/(r['id']+'.jpg'))
  det=detector.predict(path,imgsz=640,conf=.045,iou=.3,verbose=False,device='cpu')[0]
  boxes=det.boxes.xyxy.cpu().numpy()[:10];confs=det.boxes.conf.cpu().numpy()[:10]
  if len(boxes):
   learned=segmenter.predict(path,imgsz=640,conf=.05,iou=.7,retina_masks=True,verbose=False,device='cpu')[0]
   learned_boxes=learned.boxes.xyxy.cpu().numpy();overlap=box_iou(boxes,learned_boxes);points=[];methods=[]
   for j,box in enumerate(boxes):
    chosen=int(overlap[j].argmax()) if overlap.shape[1] else -1
    point=None
    if chosen>=0 and overlap[j,chosen]>=.3 and learned.masks is not None and chosen<len(learned.masks):
     mask=learned.masks.data[chosen].cpu().numpy().astype('uint8').copy()
     x1,y1,x2,y2=box;left=max(0,int(x1));top=max(0,int(y1));right=min(mask.shape[1],int(np.ceil(x2)));bottom=min(mask.shape[0],int(np.ceil(y2)))
     clipped=np.zeros_like(mask);clipped[top:bottom,left:right]=mask[top:bottom,left:right]
     distance=cv2.distanceTransform(clipped,cv2.DIST_L2,3)
     if distance.max()>0:
      y,x=np.unravel_index(int(distance.argmax()),distance.shape);point=[float(x),float(y)]
    methods.append('learned_mask' if point is not None else 'box_center')
    points.append([point if point is not None else [float((box[0]+box[2])/2),float((box[1]+box[3])/2)]])
   result=sam.predict(path,bboxes=boxes.tolist(),points=points,labels=[[1] for _ in points],conf=0.,imgsz=640,verbose=False,device='cpu')[0]
   polygons=result.masks.xyn if result.masks is not None else []
   indices=result.boxes.cls.cpu().numpy().astype(int).tolist();assert len(indices)==len(polygons)
   p=dict(polygons=[p.tolist() for p in polygons],confidence=[float(confs[j]) for j in indices],quality=result.boxes.conf.cpu().numpy().tolist(),point_methods=[methods[j] for j in indices],detected_boxes=boxes.tolist())
  else:p=dict(polygons=[],confidence=[],quality=[],point_methods=[],detected_boxes=[])
  cache.write_text(json.dumps(p))
 gt=ground_truth(r)
 for confidence in (.045,.05,.1,.15,.2,.25,.3,.4,.5):
  for quality in (0.,.5,.75):
   selected=[poly for poly,c,q in zip(p['polygons'],p['confidence'],p['quality']) if c>=confidence and q>=quality]
   mask=raster(selected,r['width'],r['height']);inter=int((gt&mask).sum());union=int((gt|mask).sum())
   report.append(dict(id=r['id'],conf=confidence,sam_quality=quality,iou=inter/max(union,1),dice=2*inter/max(int(gt.sum()+mask.sum()),1),area_mae_fraction=abs(float(gt.mean())-float(mask.mean()))))
 frame=pd.DataFrame(report);frame.to_csv(BASE/'analysis/m4_guided_refinement_per_image.csv',index=False)
 summary=frame.groupby(['conf','sam_quality']).agg(mean_iou=('iou','mean'),mean_dice=('dice','mean'),n=('id','size')).reset_index()
 summary.to_csv(BASE/'analysis/m4_guided_refinement_validation.csv',index=False)
 print('M4 guided',i+1,'/40',summary.sort_values('mean_iou',ascending=False).head(1).to_dict('records'),flush=True)
