# Model card

Research camera-trap animal foreground segmentation. The system combines the user-supplied M4 animal detector, the continued-fine-tuned M5 YOLO segmenter, and pretrained SAM ViT-B. It is a three-stage pipeline; its overlap score must not be described as standalone YOLO segmentation performance.

M4 predicts boxes at confidence floor 0.045 and NMS 0.3 (maximum 10 prompts). Each box is matched by box IoU to an inferred M5 mask (minimum 0.3); the maximum interior-distance pixel inside that box supplies a positive SAM point. If unavailable, the predicted box center is used. SAM operates at input 640. Accepted masks use globally selected detector confidence and SAM-quality thresholds in refinement_policy.json. No reference boxes or masks are read by predict_refined.py.

The original 40 validation images and references are unchanged. Thresholds and architecture were repeatedly selected on these same images; the result is a development estimate with selection optimism. References are SAM-assisted and team-reviewed, so teacher/reference style bias is possible. No test images were used in these experiments. The original v1 test had already been inspected by the team; a genuinely independent future test is needed for generalization claims.

The M4 checkpoint was supplied by the user; its training provenance was not independently reproduced. The M5 continuation used 150 training images for 12 epochs, six assistant-reviewed background polygons removed from a derived training copy, and preserved original labels. It used CPU bfloat16 autocast, FP32 optimizer, AdamW, lr 0.0002, no warmup or mosaic. An attempted BatchNorm-freezing callback was ineffective: BatchNorm running statistics updated. See actual_configuration_correction.json.

The AP values in selected_validation_ap.json belong only to standalone M5 YOLO. AP has not been measured for this three-stage pipeline. Foreground-area error is a relative image fraction, not a physical size estimate.

mask_count counts accepted segmentation masks after quality filtering, not all animals and not the original M4 triage count. detector_prompt_count counts predictions at the prompt floor, capped at 10; it is not a validated population count. The higher segmentation confidence does not establish M4's original 99% animal-recall criterion.

Use with human review. Missed/occluded animals, small objects, low light, domain shift and reference ambiguity remain limitations. CPU inference is slow; a GPU is recommended. SAM is fetched from the official Ultralytics release and its SHA256 is verified.
