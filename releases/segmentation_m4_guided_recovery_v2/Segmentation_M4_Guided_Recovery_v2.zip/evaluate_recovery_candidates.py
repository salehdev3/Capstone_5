from evaluate import *
from collections import Counter
out=BASE/'analysis/recovery_candidates';out.mkdir(exist_ok=True)
policy=json.loads(Path('/workspace/exports/Segmentation_M4_Guided/refinement_policy.json').read_text())
cache=BASE/('m4_guided_cache_'+policy['detector_sha256'][:8]+'_'+policy['segmenter_sha256'][:8])
rows=[]
for r in VAL:
 p=json.loads((cache/(r['id']+'.json')).read_text())
 assert digest(ROOT/'dataset/labels/val_select'/(r['id']+'.txt'))==policy['reference_label_sha256'][r['id']]
 raw=list(zip(p['polygons'],p['confidence'],p['quality']))
 primary=[x for x in raw if x[1]>=policy['conf'] and x[2]>=policy['sam_quality']]
 for method in ['original','fallback_best_prompt','fallback_all_prompts','original_triage_floor_all']:
  chosen=primary
  fallback=[x for x in raw if x[1]>=policy['prompt_floor'] and x[2]>=policy['sam_quality']]
  if method=='fallback_best_prompt' and not primary:chosen=sorted(fallback,key=lambda x:x[1],reverse=True)[:1]
  if method=='fallback_all_prompts' and not primary:chosen=fallback
  if method=='original_triage_floor_all':chosen=fallback
  gt=ground_truth(r);mask=raster([x[0] for x in chosen],r['width'],r['height'])
  inter=int((gt&mask).sum());union=int((gt|mask).sum())
  rows.append(dict(id=r['id'],method=method,iou=inter/max(union,1),dice=2*inter/max(int(gt.sum()+mask.sum()),1),masks=len(chosen),used_fallback=not bool(primary) and bool(chosen),area_mae_fraction=abs(float(gt.mean())-float(mask.mean()))))
f=pd.DataFrame(rows);f.to_csv(out/'validation_per_image.csv',index=False)
s=f.groupby('method').agg(mean_iou=('iou','mean'),mean_dice=('dice','mean'),n=('id','size'),zero_mask_images=('masks',lambda s:s.eq(0).sum()),fallback_images=('used_fallback','sum'),area_mae_fraction=('area_mae_fraction','mean')).reset_index()
s.to_csv(out/'validation_comparison.csv',index=False)
assert abs(s.loc[s.method.eq('original'),'mean_iou'].iloc[0]-policy['validation']['mean_iou'])<1e-12
print(s.to_string(index=False))
